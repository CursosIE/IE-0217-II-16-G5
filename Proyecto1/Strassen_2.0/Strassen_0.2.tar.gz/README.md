EmmaDu

1)	Recibe las dimensiones de las matrices que se van a multiplicar desde la terminal de la siguiente manera:
		./mS n,m i,j

2)	Para compilar y ejecutar el código: make

3)	Para cambiar las dimensiones: modificar el Makefile
